/*
 * C�digo-fonte do livro "Programando Java para Web"
 * Autores: D�cio Heinzelmann Luckow <decioluckow@gmail.com>
 *          Alexandre Altair de Melo <alexandremelo.br@gmail.com>
 *
 * ISBN: 978-85-7522-238-6
 * http://www.novatec.com.br/livros/javaparaweb
 * Editora Novatec, 2010 - todos os direitos reservados
 *
 * LICEN�A: Este arquivo-fonte est� sujeito a Atribui��o 2.5 Brasil, da licen�a Creative Commons,
 * que encontra-se dispon�vel no seguinte endere�o URI: http://creativecommons.org/licenses/by/2.5/br/
 * Se voc� n�o recebeu uma c�pia desta licen�a, e n�o conseguiu obt�-la pela internet, por favor,
 * envie uma notifica��o aos seus autores para que eles possam envi�-la para voc� imediatamente.
 *
 *
 * Source-code of "Programando Java para Web" book
 * Authors: D�cio Heinzelmann Luckow <decioluckow@gmail.com>
 *          Alexandre Altair de Melo <alexandremelo.br@gmail.com>
 *
 * ISBN: 978-85-7522-238-6
 * http://www.novatec.com.br/livros/javaparaweb
 * Editora Novatec, 2010 - all rights reserved
 *
 * LICENSE: This source file is subject to Attribution version 2.5 Brazil of the Creative Commons
 * license that is available through the following URI:  http://creativecommons.org/licenses/by/2.5/br/
 * If you did not receive a copy of this license and are unable to obtain it through the web, please
 * send a note to the authors so they can mail you a copy immediately.
 *
 */
package com.livro.capitulo3.consulta;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.livro.capitulo3.filme.Filme;
import com.livro.capitulo3.util.HibernateUtil;

public class Consultas {

	private Session	sessao	= HibernateUtil.getSessionFactory().openSession();

	public static void main(String[] args) {
		Consultas consultas = new Consultas();
		consultas.queryConsultas();
		consultas.criteriaConsultas();
		consultas.consultasNomeadas();
	}

	public void queryConsultas() {
			
	}

	public void criteriaConsultas() {

	}

	public void consultasNomeadas() {
		this.sessao = HibernateUtil.getSessionFactory().openSession();
		Query consulta = null;
		Filme filme = null;
		List<Filme> filmes = null;

		//Buscando pela chave prim�ria
		consulta = this.sessao.getNamedQuery("filmePorChavePrimaria");
		consulta.setParameter("filme", 1);
		filme = (Filme) consulta.uniqueResult();
		System.out.println("Usando consultas nomeadas o nome do filme �: " + filme.getDescricao());

		//Buscando pela descri��o
		consulta = this.sessao.getNamedQuery("filmePorDescricao");
		consulta.setParameter("descricao", "%e%");
		filmes = consulta.list();
		System.out.println("Segue(m) o(s) filme(s) da descri��o pesquisada.");
		for (Filme f: filmes) {
			System.out.println("O nome do filme �: " + f.getDescricao());
		}

		//Buscando por categoria
		consulta = this.sessao.getNamedQuery("filmePorCategoria");
		consulta.setParameter("categoria", 1);
		filmes = consulta.list();
		System.out.println("Segue(m) o(s) filme(s) da categoria pesquisada.");
		for (Filme f: filmes) {
			System.out.println("O nome do filme �: " + f.getDescricao());
		}
	}
}
